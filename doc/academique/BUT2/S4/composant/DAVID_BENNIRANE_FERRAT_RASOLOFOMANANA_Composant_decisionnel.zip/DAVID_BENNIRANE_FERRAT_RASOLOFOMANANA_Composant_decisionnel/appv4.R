library(shiny)
library(DT)
library(dplyr)
library(ggplot2)
library(maps)

# 
# DONNÉES


base_clean <- read.csv("hotel_bookings_clean.csv")

# Dictionnaire ISO : nom complet de pays
pays_noms <- c(
  MAR="Maroc", VEN="Venezuela", ABW="Aruba", AGO="Angola", AIA="Anguilla",
  ALB="Albanie", AND="Andorre", ARE="Émirats arabes unis",
  ARG="Argentine", ARM="Arménie", ASM="Samoa américaines",
  ATA="Antarctique", ATF="Terres australes françaises", AUS="Australie",
  AUT="Autriche", AZE="Azerbaïdjan", BDI="Burundi", BEL="Belgique",
  BEN="Bénin", BFA="Burkina Faso", BGD="Bangladesh", BGR="Bulgarie",
  BHR="Bahreïn", BHS="Bahamas", BIH="Bosnie-Herzégovine",
  BLR="Biélorussie", BOL="Bolivie", BRA="Brésil", BRB="Barbade",
  BWA="Botswana", CAF="Rép. centrafricaine", CHE="Suisse",
  CHL="Chili", CHN="Chine", CIV="Côte d'Ivoire", CMR="Cameroun",
  CN="Chine", COL="Colombie", COM="Comores", CPV="Cap-Vert",
  CRI="Costa Rica", CUB="Cuba", CYM="Îles Caïmans", CYP="Chypre",
  CZE="Tchéquie", DEU="Allemagne", DNK="Danemark", DOM="Rép. dominicaine",
  DZA="Algérie", ECU="Équateur", EGY="Égypte", ESP="Espagne",
  EST="Estonie", ETH="Éthiopie", FIN="Finlande", FRA="France",
  GBR="Royaume-Uni", GRC="Grèce", HRV="Croatie", HUN="Hongrie",
  IDN="Indonésie", IND="Inde", IRL="Irlande", ISL="Islande",
  ISR="Israël", ITA="Italie", JPN="Japon", KOR="Corée du Sud",
  LUX="Luxembourg", MAR="Maroc", MEX="Mexique",
  NLD="Pays-Bas", NOR="Norvège", POL="Pologne",
  PRT="Portugal", ROU="Roumanie", RUS="Russie",
  SAU="Arabie saoudite", SWE="Suède", TUR="Turquie",
  USA="États-Unis", ZAF="Afrique du Sud", NULL="Inconnu"
)

base_clean$pays_nom <- ifelse(
  base_clean$pays %in% names(pays_noms),
  pays_noms[base_clean$pays],
  base_clean$pays
)

# Ordre et labels des mois pour les graphiques
ordre_mois  <- c("January","February","March","April","May","June",
                 "July","August","September","October","November","December")
labels_mois <- c("Jan","Fév","Mar","Avr","Mai","Juin",
                 "Juil","Août","Sep","Oct","Nov","Déc")

# 
# PALETTE COULEURS
#

# Dégradé navy du plus foncé au plus clair
pal_blues <- c("#0B1F3A", "#153A6E", "#2563B0", "#6B9FD4", "#9BBFE0", "#C0D9F0", "#E8F2FA")

# Pour les graphiques City Hotel / Resort Hotel
pal_hotel_fill  <- c("City Hotel" = "#2563B0", "Resort Hotel" = "#6B9FD4")
pal_hotel_color <- c("City Hotel" = "#0B1F3A", "Resort Hotel" = "#153A6E")


# UI


ui <- fluidPage(
  
  tags$head(
    tags$meta(name = "viewport", content = "width=device-width, initial-scale=1"),
    tags$style(HTML("

      /* Corps de page */
      body {
        background-color: #F0F4F8;
        font-family: 'Segoe UI', sans-serif;
        color: #0B1F3A;
      }

      .container-fluid {
        padding-left: 16px !important;
        padding-right: 16px !important;
      }

      /* Header avec logo */
      .header-band {
        background: linear-gradient(135deg, #0B1F3A 0%, #153A6E 60%, #2563B0 100%);
        padding: 18px 30px;
        margin-bottom: 24px;
        border-radius: 0 0 16px 16px;
        box-shadow: 0 4px 16px rgba(11,31,58,0.22);
      }

      /* Onglets de navigation */
      .nav-tabs {
        border-bottom: 2px solid #2563B0;
        margin-bottom: 20px;
      }
      .nav-tabs > li > a {
        color: #2563B0;
        font-weight: 600;
        border-radius: 8px 8px 0 0;
        border: 1px solid transparent;
        padding: 9px 18px;
      }
      .nav-tabs > li.active > a,
      .nav-tabs > li.active > a:focus,
      .nav-tabs > li.active > a:hover {
        background-color: #2563B0;
        color: #ffffff !important;
        border-color: #2563B0;
      }
      .nav-tabs > li > a:hover {
        background-color: #C0D9F0;
        color: #0B1F3A;
      }

      /* Contenu de chaque onglet */
      .tab-content {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 28px 30px;
        box-shadow: 0 2px 12px rgba(21,58,110,0.07);
        margin-bottom: 30px;
      }

      /* Titres */
      h1 {
        color: #0B1F3A;
        font-weight: 700;
        font-size: 2.6rem;
        padding-left: 12px;
        margin-bottom: 18px;
      }
      h2 {
        color: #153A6E;
        font-weight: 600;
        font-size: 1.9rem;
        margin-top: 10px;
      }
      h3 {
        color: #2563B0;
        font-weight: 600;
        font-size: 1.5rem;
        margin-bottom: 12px;
      }
      h4 {
        font-size: 1.3rem;
        font-weight: 600;
        color: #0B1F3A;
      }
      h5 {
        color: #6B9FD4;
        font-size: 1.05rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.07em;
        margin-bottom: 8px;
      }

      /* Texte courant */
      p, li {
        font-size: 1.12rem;
        line-height: 1.7;
      }

      /* KPI cards (wellPanel) */
      .well {
        background-color: #ffffff;
        border: none;
        border-top: 4px solid #2563B0;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(21,58,110,0.09);
        padding: 16px 18px;
      }
      .well h3 {
        color: #0B1F3A;
        font-size: 1.6rem;
        font-weight: 800;
        margin: 4px 0 0 0;
        border: none;
      }

      /* Selects et sliders */
      .selectize-input {
        border: 1.5px solid #C0D9F0 !important;
        border-radius: 7px !important;
        box-shadow: none !important;
        color: #0B1F3A;
      }
      .selectize-dropdown {
        border: 1.5px solid #C0D9F0;
        border-radius: 7px;
      }
      .irs--shiny .irs-bar {
        background: #2563B0;
        border-color: #2563B0;
      }
      .irs--shiny .irs-handle {
        background: #2563B0;
        border-color: #153A6E;
      }

      /* Listes */
      ul li {
        margin-bottom: 5px;
        line-height: 1.6;
      }

      /* Tableau de données */
      .dataTables_wrapper {
        font-size: 0.88rem;
      }
      table.dataTable thead th {
        background-color: #2563B0 !important;
        color: white !important;
        font-weight: 600;
        border: none !important;
      }
      table.dataTable tbody tr:hover {
        background-color: #C0D9F0 !important;
      }

      /* Blocs de section (fond gris-bleu encadré) */
      .box-section {
        background-color: #EEF3F8;
        border: 1px solid #D6E1EE;
        border-radius: 12px;
        padding: 15px;
        margin-bottom: 25px;
        min-height: 320px;
        line-height: 1.7;
        overflow: hidden;
      }
      .box-section > div {
        width: 100%;
      }
      /* Tableau scrollable horizontalement s'il dépasse */
      .box-section .dataTables_wrapper {
        overflow-x: auto;
        width: 100%;
      }

      /* Titre de section avec barre bleue */
      .section-title {
        border-left: 5px solid #2563B0;
        padding-left: 10px;
        margin-bottom: 10px;
        font-weight: 600;
        color: #153A6E;
      }

      /* Blocs petits (onglet contexte ligne 1) */
      .box-small {
        background-color: #EEF3F8;
        border: 1px solid #D6E1EE;
        border-radius: 12px;
        padding: 10px 20px;
        margin-bottom: 25px;
        min-height: 110px;
      }

      /* Blocs grands (onglet contexte ligne 2) */
      .box-large {
        background-color: #EEF3F8;
        border: 1px solid #D6E1EE;
        border-radius: 12px;
        padding: 10px 20px;
        margin-bottom: 25px;
        min-height: 280px;
      }

    "))
  ),
  
  # Header avec logo
  div(class = "header-band",
      img(src = "image.png", height = "70px")
  ),
  
  tabsetPanel(
  
    
    # ONGLET 1 : DONNÉES & CONTEXTE
    
    tabPanel("Données & contexte",
             
             h1("BIENVENUE SUR HOTELSENSE !"),
             
             p("Vous êtes gestionnaire ou travaillez dans le domaine de l'hôtellerie ?"),
             p("Cette application est faite pour vous."),
             p("Elle permet d'explorer des données de réservations pour mieux comprendre comment fonctionne l'activité hôtelière."),
             
             br(),
             
             # Ligne 1 : fonctionnalités + source des données
             fluidRow(
               column(6,
                      h2(class = "section-title", "Ce que vous pouvez faire"),
                      div(class = "box-small",
                          tags$ul(
                            tags$li("Visualiser l'évolution des réservations au fil du temps"),
                            tags$li("Analyser le comportement des clients (prix, durée du séjour, délai de réservation)"),
                            tags$li("Repérer les périodes avec beaucoup d'annulations"),
                            tags$li("Comparer les performances selon le type d'hôtel")
                          )
                      )
               ),
               column(6,
                      h2(class = "section-title", "Source des données"),
                      div(class = "box-small",
                          p("Les données utilisées dans cette application proviennent d'un jeu de données public disponible sur", tags$b("Kaggle.")),
                          p("Elles regroupent des réservations d'hôtels entre 2015 et 2017."),
                          p("Le jeu de données contient environ", tags$b("117 000 réservations"), "et", tags$b("13 variables"), "liées aux clients et aux séjours.")
                      )
               )
             ),
             
             br(),
             
             # Ligne 2 : variables + nettoyage
             fluidRow(
               column(6,
                      h2(class = "section-title", "Description des variables"),
                      div(class = "box-section",
                          tags$ul(
                            tags$li(tags$b("hotel"), " : type d'hôtel (Resort Hotel / City Hotel)"),
                            tags$li(tags$b("annulation"), " : 1 = réservation annulée, 0 = séjour effectué"),
                            tags$li(tags$b("delai_reservation"), " : nombre de jours entre la réservation et l'arrivée"),
                            tags$li(tags$b("annee_arrivee / mois_arrivee"), " : date d'arrivée prévue"),
                            tags$li(tags$b("segment_marche"), " : canal de commercialisation (Online TA, Direct, Corporate...)"),
                            tags$li(tags$b("canal_distribution"), " : canal par lequel la réservation a transité"),
                            tags$li(tags$b("type_depot"), " : condition de dépôt / acompte"),
                            tags$li(tags$b("type_client"), " : profil du client (Transient, Contract, Group...)"),
                            tags$li(tags$b("pays"), " : pays de résidence du client"),
                            tags$li(tags$b("prix_nuit"), " : prix moyen par nuit en euros"),
                            tags$li(tags$b("total_personnes"), " : nombre total de personnes"),
                            tags$li(tags$b("total_nuits"), " : durée totale du séjour en nuits")
                          )
                      )
               ),
               column(6,
                      h2(class = "section-title", "Nettoyage des données"),
                      div(class = "box-section",
                          tags$ul(
                            tags$li("Suppression de la colonne company (>94% de valeurs manquantes)"),
                            tags$li("Suppression des réservations avec 0 clients"),
                            tags$li("Suppression des prix aberrants"),
                            tags$li("Suppression des séjours de 0 nuit"),
                            tags$li("Imputation des valeurs manquantes"),
                            tags$li("Création de total_personnes"),
                            tags$li("Création de total_nuits")
                          )
                      )
               )
             ),
             
             br(),
             
             # Ligne 3 : aperçu tableau
             h2(class = "section-title", "Aperçu des données"),
             p("Exemple de 10 observations sélectionnées aléatoirement dans le jeu de données."),
             div(class = "box-section",
                 DTOutput("table_data")
             ),
             
             br(),
             hr(),
             
             div(
               style = "text-align:center; font-size:0.95rem; color:#6B9FD4; margin-top:10px;",
               p("Application développée par : Nawel BENNIRANE, Christella DAVID, Lina FERRAT, Santatriniaina RASOLOFOMANANA"),
               p("Composant décisionnel - Fait le 06/06/2026")
             )
    ),
    
    # ONGLET 2 : ACTIVITÉ HÔTELIÈRE
    tabPanel("Activité hôtelière",
             
             h1("Vue d'ensemble de l'activité des réservations"),
             
             p("Cette section vous permet de visualiser rapidement les tendances des réservations et d'identifier les périodes importantes."),
             p("Filtrez les données pour analyser plus précisément l'activité."),
             
             br(),
             
             # Filtres
             fluidRow(
               column(4,
                      selectInput("filtre_hotel", "Type d'hôtel",
                                  choices = c("Tous", unique(base_clean$hotel)),
                                  selected = "Tous")
               ),
               column(4,
                      selectInput("filtre_annee", "Année",
                                  choices = c("Toutes", unique(base_clean$annee_arrivee)),
                                  selected = "Toutes")
               )
             ),
             
             br(),
             
             # KPI
             fluidRow(
               column(3,
                      wellPanel(
                        h5("Nombre de réservations"),
                        h3(textOutput("kpi_resa"))
                      )
               ),
               column(3,
                      wellPanel(
                        h5("Prix moyen / nuit"),
                        h3(textOutput("kpi_prix"))
                      )
               ),
               column(3,
                      wellPanel(
                        h5("Durée moyenne de séjour"),
                        h3(textOutput("kpi_duree"))
                      )
               )
             ),
             
             # Graphiques ligne 1
             fluidRow(
               column(6,
                      h3(class = "section-title", "Evolution mensuelle des réservations"),
                      div(class = "box-small", plotOutput("plot_reservations", height = "300px"))
               ),
               column(6,
                      h3(class = "section-title", "Réservation selon le type d'hôtel"),
                      div(class = "box-small", plotOutput("plot_hotel", height = "300px"))
               )
             ),
             
             # Graphiques ligne 2
             fluidRow(
               column(6,
                      h3(class = "section-title", "Comparaison des prix selon le type d'hôtel"),
                      div(class = "box-small", plotOutput("plot_prix", height = "300px"))
               ),
               column(6,
                      h3(class = "section-title", "Réservations réalisées vs annulées"),
                      div(class = "box-small", plotOutput("plot_annulation", height = "300px"))
               )
             )
    ),
    
    # ONGLET 3 : PROFIL & COMPORTEMENT CLIENTS
    tabPanel("Profil & comportement des clients",
             
             h1("Caractéristiques des clients"),
             
             p("Cette section permet de mieux comprendre d'où viennent les clients, comment ils réservent et leur type de clientèle."),
             
             br(),
             
             # Filtres
             fluidRow(
               column(4,
                      selectInput("filtre_hotel_client", "Type d'hôtel",
                                  choices = c("Tous", unique(base_clean$hotel)),
                                  selected = "Tous")
               ),
               column(4,
                      selectInput("filtre_type_client", "Type de client",
                                  choices = c("Tous", unique(base_clean$type_client)),
                                  selected = "Tous")
               ),
               column(4,
                      selectInput("filtre_pays", "Pays",
                                  choices = c("Tous", sort(unique(base_clean$pays_nom))),
                                  selected = "Tous")
               )
             ),
             
             # Graphiques ligne 1
             fluidRow(
               column(6,
                      h3(class = "section-title", "Quels types de clients réservent le plus ?"),
                      div(class = "box-section", plotOutput("plot_type_client"))
               ),
               column(6,
                      h3(class = "section-title", "Comment les clients réservent-ils ?"),
                      div(class = "box-section", plotOutput("plot_segment"))
               )
             ),
             
             br(),
             
             # Graphiques ligne 2
             fluidRow(
               column(6,
                      h3(class = "section-title", "Combien de nuits les clients restent-ils ?"),
                      div(class = "box-section", plotOutput("plot_duree"))
               ),
               column(6,
                      h3(class = "section-title", "Les pays qui vous apportent le plus de clients"),
                      div(class = "box-section", plotOutput("plot_pays"))
               )
             ),
             
             br(),
             
             # Carte monde
             fluidRow(
               column(12,
                      h3(class = "section-title", "Origine des clients dans le monde"),
                      div(class = "box-section", plotOutput("plot_carte", height = "500px"))
               )
             )
    ),
    
    # ONGLET 4 : SIMULATION
    tabPanel("Simulation de réservation",
             
             h1("Simulez une réservation et analysez le résultat !"),
             p("Explorez différents scénarios de réservation pour mieux comprendre le risque d'annulation et les revenus potentiels."),
             
             fluidRow(
               
               # Colonne paramètres
               column(4,
                      h3("Simulation"),
                      p("Renseignez les caractéristiques d'une réservation."),
                      br(),
                      selectInput("sim_hotel", "Type d'hôtel",
                                  choices = unique(base_clean$hotel)),
                      selectInput("sim_type_client", "Type de client",
                                  choices = unique(base_clean$type_client)),
                      selectInput("sim_depot", "Type de dépôt",
                                  choices = unique(base_clean$type_depot)),
                      selectInput("sim_mois", "Mois d'arrivée",
                                  choices = unique(base_clean$mois_arrivee)),
                      sliderInput("sim_delai", "Délai de réservation (jours)",
                                  min = 0,
                                  max = max(base_clean$delai_reservation),
                                  value = 30)
               ),
               
               # Colonne résultats
               column(8,
                      h2("Résultats"),
                      br(),
                      uiOutput("box_risque"),
                      wellPanel(
                        h5("SIMULATION DES REVENUS"),
                        textOutput("sim_prix"),
                        textOutput("sim_revenu"),
                        textOutput("sim_gain")
                      ),
                      wellPanel(
                        h5("RECOMMANDATION"),
                        textOutput("sim_decision")
                      )
               )
             )
    )
  )
)

# SERVER

server <- function(input, output) {
  
  # ONGLET 1 : tableau 
  
  output$table_data <- renderDT({
    idx <- sample(nrow(base_clean), 10)
    datatable(base_clean[idx, ],
              options = list(dom = 't'),
              rownames = FALSE)
  })
  
  # ONGLET 2 : données filtrées 
  
  data_filtre <- reactive({
    df <- base_clean
    if (input$filtre_hotel != "Tous")   df <- df %>% filter(hotel == input$filtre_hotel)
    if (input$filtre_annee != "Toutes") df <- df %>% filter(annee_arrivee == input$filtre_annee)
    df
  })
  
  # KPI
  output$kpi_resa  <- renderText({ nrow(data_filtre()) })
  output$kpi_prix  <- renderText({ paste0(round(mean(data_filtre()$prix_nuit), 1), " €") })
  output$kpi_duree <- renderText({ paste0(round(mean(data_filtre()$total_nuits), 1), " nuits") })
  
  # Courbe réservations par mois
  output$plot_reservations <- renderPlot({
    df <- data_filtre() %>%
      mutate(mois_arrivee = factor(mois_arrivee, levels = ordre_mois)) %>%
      count(mois_arrivee)
    
    ggplot(df, aes(x = mois_arrivee, y = n, group = 1)) +
      geom_line(color = pal_blues[2], linewidth = 1.2) +
      geom_point(color = pal_blues[1], size = 2.5) +
      geom_text(aes(label = n), vjust = -0.7, size = 3.5, color = pal_blues[2]) +
      scale_x_discrete(labels = labels_mois) +
      labs(x = "Mois", y = "Nombre de réservations") +
      theme_minimal()
  })
  
  # Barres répartition par type d'hôtel
  output$plot_hotel <- renderPlot({
    data_filtre() %>%
      count(hotel) %>%
      ggplot(aes(x = hotel, y = n, fill = hotel)) +
      geom_col(width = 0.5, show.legend = FALSE) +
      geom_text(aes(label = n), vjust = -0.5) +
      scale_fill_manual(values = pal_hotel_fill) +
      labs(title = "Répartition des réservations", x = "Type d'hôtel", y = "Nombre") +
      theme_minimal()
  })
  
  # Distribution des prix par nuit
  output$plot_prix <- renderPlot({
    data_filtre() %>%
      filter(prix_nuit > 0 & prix_nuit < quantile(prix_nuit, 0.99)) %>%
      ggplot(aes(x = prix_nuit, color = hotel, fill = hotel)) +
      geom_histogram(aes(y = after_stat(density)), bins = 40, alpha = 0.2, position = "identity") +
      geom_density(fill = NA, linewidth = 1.3) +
      scale_fill_manual(values = c("City Hotel" = pal_blues[4], "Resort Hotel" = pal_blues[6])) +
      scale_color_manual(values = c("City Hotel" = pal_blues[1], "Resort Hotel" = pal_blues[3])) +
      labs(x = "Prix (€) / nuit", y = "Fréquence des prix",
           fill = "Type d'hôtel", color = "Type d'hôtel") +
      theme_minimal()
  })
  
  # Donut réalisées vs annulées
  output$plot_annulation <- renderPlot({
    df <- data_filtre() %>%
      count(annulation) %>%
      mutate(statut = ifelse(annulation == 1, "Annulée", "Réalisée"))
    
    ggplot(df, aes(x = 2, y = n, fill = statut)) +
      geom_col(width = 1) +
      coord_polar(theta = "y") +
      xlim(0.5, 2.5) +
      geom_text(aes(label = paste0(round(n / sum(n) * 100, 1), "%")),
                position = position_stack(vjust = 0.5), color = "white", size = 4) +
      scale_fill_manual(values = c("Réalisée" = pal_blues[3], "Annulée" = "#E8613A")) +
      labs(fill = "Statut") +
      theme_void()
  })
  
  #ONGLET 3 : données clients filtrées 
  
  data_clients <- reactive({
    df <- base_clean
    if (input$filtre_hotel_client != "Tous")  df <- df %>% filter(hotel == input$filtre_hotel_client)
    if (input$filtre_type_client != "Tous")   df <- df %>% filter(type_client == input$filtre_type_client)
    if (input$filtre_pays != "Tous")          df <- df %>% filter(pays_nom == input$filtre_pays)
    df
  })
  
  # Camembert types de clients
  output$plot_type_client <- renderPlot({
    df <- data_clients() %>% count(type_client)
    
    ggplot(df, aes(x = "", y = n, fill = type_client)) +
      geom_col(width = 1) +
      coord_polar("y") +
      scale_fill_manual(values = setNames(pal_blues[1:length(unique(base_clean$type_client))],
                                          unique(base_clean$type_client))) +
      geom_text(aes(label = paste0(round(n / sum(n) * 100, 1), "%")),
                position = position_stack(vjust = 0.5), color = "white", size = 4) +
      labs(title = "Répartition des types de clients", fill = "Type de client") +
      theme_void()
  })
  
  # Barres modes de réservation
  output$plot_segment <- renderPlot({
    data_clients() %>%
      count(segment_marche) %>%
      ggplot(aes(x = reorder(segment_marche, n), y = n)) +
      geom_col(fill = pal_blues[2]) +
      geom_text(aes(label = n), hjust = -0.2, size = 3) +
      coord_flip() +
      labs(title = "Modes de réservation des clients",
           x = "Modes de réservation", y = "Nombre de réservations") +
      theme_minimal()
  })
  
  # Camembert durées de séjour
  output$plot_duree <- renderPlot({
    df <- data_clients() %>%
      mutate(categorie_duree = case_when(
        total_nuits <= 2  ~ "1-2 nuits",
        total_nuits <= 5  ~ "3-5 nuits",
        total_nuits <= 14 ~ "6-14 nuits",
        total_nuits <= 30 ~ "15-30 nuits",
        TRUE              ~ "30+ nuits"
      )) %>%
      count(categorie_duree)
    
    ggplot(df, aes(x = "", y = n, fill = categorie_duree)) +
      geom_col(width = 1) +
      coord_polar("y") +
      geom_text(aes(label = paste0(round(n / sum(n) * 100, 1), "%")),
                position = position_stack(vjust = 0.5), color = "white", size = 4) +
      scale_fill_manual(values = c(
        "1-2 nuits"   = pal_blues[1],
        "3-5 nuits"   = pal_blues[2],
        "6-14 nuits"  = pal_blues[3],
        "15-30 nuits" = pal_blues[5],
        "30+ nuits"   = pal_blues[7]
      )) +
      labs(title = "Répartition des durées de séjour", fill = "Durée") +
      theme_void()
  })
  
  # Barres top 10 pays
  output$plot_pays <- renderPlot({
    df <- data_clients() %>%
      count(pays_nom) %>%
      arrange(desc(n)) %>%
      head(10)
    
    ggplot(df, aes(x = reorder(pays_nom, n), y = n)) +
      geom_col(fill = pal_blues[3]) +
      geom_text(aes(label = n), hjust = -0.2, size = 3) +
      coord_flip() +
      labs(title = "Top 10 des pays les plus représentés",
           x = "Pays", y = "Nombre de réservations") +
      theme_minimal()
  })
  
  # Carte choroplèthe monde
  output$plot_carte <- renderPlot({
    world        <- map_data("world")
    df_pays      <- data_clients() %>% count(pays_nom) %>% rename(region = pays_nom)
    map_complet  <- left_join(world, df_pays, by = "region")
    
    ggplot(map_complet, aes(x = long, y = lat, group = group, fill = n)) +
      geom_polygon(color = "white", linewidth = 0.2) +
      scale_fill_gradient(low = "#EEF7FF", high = "#2563B0",
                          na.value = "#E0E0E0", name = "Nb clients") +
      theme_void()
  })
  
  #ONGLET 4 : simulation 
  
  data_sim <- reactive({
    base_clean %>%
      filter(
        hotel        == input$sim_hotel,
        type_client  == input$sim_type_client,
        type_depot   == input$sim_depot,
        mois_arrivee == input$sim_mois,
        delai_reservation >= input$sim_delai - 15,
        delai_reservation <= input$sim_delai + 15
      )
  })
  
  output$sim_prix <- renderText({
    df <- data_sim()
    if (nrow(df) == 0) return("")
    paste0("Prix moyen : ", round(mean(df$prix_nuit), 1), " €")
  })
  
  output$sim_revenu <- renderText({
    df <- data_sim()
    if (nrow(df) == 0) return("")
    paste0("Revenu total : ", round(mean(df$prix_nuit) * mean(df$total_nuits), 1), " €")
  })
  
  output$sim_gain <- renderText({
    df <- data_sim()
    if (nrow(df) == 0) return("")
    taux <- mean(df$annulation)
    gain <- mean(df$prix_nuit) * mean(df$total_nuits) * (1 - taux)
    paste0("Gain attendu : ", round(gain, 1), " €")
  })
  
  output$sim_decision <- renderText({
    df <- data_sim()
    if (nrow(df) == 0) return("")
    taux <- mean(df$annulation)
    if (taux < 0.3) " Accepter la réservation" else
      if (taux < 0.6) "️ Accepter avec conditions (acompte conseillé)" else
        " Réservation risquée : sécuriser ou refuser"
  })
  
  # Bloc risque avec couleur dynamique
  output$box_risque <- renderUI({
    df <- data_sim()
    
    if (nrow(df) == 0) return(wellPanel("Pas de données"))
    
    taux     <- mean(df$annulation)
    taux_pct <- round(taux * 100, 1)
    
    # Couleur de fond selon le niveau de risque
    couleur <- if (taux < 0.3) "#DFF5E1" else if (taux < 0.6) "#FFE5B4" else "#F8D7DA"
    texte   <- if (taux < 0.3) "Risque faible" else if (taux < 0.6) "Risque moyen" else "Risque élevé"
    
    div(
      style = paste0("background-color:", couleur, "; padding:20px; border-radius:10px;"),
      h5("RISQUE D'ANNULATION"),
      h2(paste0(taux_pct, " %")),
      p(texte)
    )
  })
  
}

shinyApp(ui = ui, server = server)