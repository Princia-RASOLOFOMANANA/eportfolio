# ================================================================
# SAE REPORTING D'UNE ANALYSE MULTIVARIEE
# ANALYSE DES DONNÉES OPEN FOOD FACTS
# Santé publique France — Qualité nutritionnelle des produits
# ----------------------------------------------------------------
# Christella DAVID & Santatriniaina RASOLOFOMANANA
# BUT SD - 2AFA — VCOD
# IUT de Paris – Rives de Seine | 2025-2026
# ================================================================

# Chargement des packages nécessaires
library(shiny)
library(shinydashboard)
library(tidyverse)
library(DT)
library(FactoMineR)
library(factoextra)

# ================================================================
# CHARGEMENT DES DONNEES NETTOYEES
# ================================================================


data <- read.csv(
  "donnees_nettoyees.csv", # fichier à placer dans le même dossier que app.R
  stringsAsFactors = FALSE
)

# ================================================================
# PALETTES DE COULEUR
# ================================================================

# Couleurs principales utilisées dans tout le dashboard
vert   <- "#2ECC71"
jaune  <- "#F1C40F"
orange <- "#E67E22"
rouge  <- "#E74C3C"
bleu   <- "#2980B9"
gris   <- "#95A5A6"

# Palettes par type de variable catégorielle
couleurs_ns <- c("A"=vert,"B"="#A3E4D7","C"=jaune,"D"=orange,"E"=rouge)
couleurs_sucre  <- c("Faible"=vert,"Moyen"=jaune,"Élevé"=rouge)
couleurs_ener   <- c("Faible"=vert,"Moyenne"=jaune,"Élevée"=rouge)
couleurs_prot   <- c("Oui"=bleu,"Non"=gris)

# Thème graphique commun à tous les graphiques du dashboard
theme_off <- theme_minimal(base_size = 13) +
  theme(
    plot.title    = element_text(face = "bold", size = 14, color = "#2c3e50"),
    plot.subtitle = element_text(size = 11, color = "#7f8c8d"),
    axis.text.x   = element_text(angle = 45, hjust = 1),
    panel.grid.minor = element_blank(),
    legend.position  = "bottom"
  )

# ================================================================
# PRÉ-CALCULS (avant ui/server)
# ================================================================

# Quelques comptages globaux pour les KPI affichés en page d'accueil
nb_produits <- nrow(data)
nb_uniques  <- length(unique(data$nom_produit))
nb_groupes  <- length(unique(data$groupe))

# On sélectionne uniquement les variables numériques pour l'ACP et le clustering
# (energie, sucre, protéines, nutriscore — les 4 variables nutritionnelles quantitatives)
data_num <- data %>%
  select(energie_100g, sucre_100g, proteine_100g, nutriscore)

# ACP (Analyse en Composantes Principales) — on réduit les données à leurs axes principaux
# scale.unit = TRUE : on normalise les variables pour qu'elles soient comparables entre elles
acp <- PCA(data_num, scale.unit = TRUE, graph = FALSE)

# Clustering K-means : on regroupe automatiquement les produits en 3 profils nutritionnels
# set.seed pour que les résultats soient reproductibles d'une exécution à l'autre
set.seed(123)
km  <- kmeans(data_num, centers = 3, nstart = 25)
data$cluster <- as.factor(km$cluster)

# Tableau résumé des caractéristiques moyennes de chaque cluster
profils_clusters <- aggregate(data_num,
                              by = list(Cluster = km$cluster), mean) %>%
  mutate(across(where(is.numeric), ~round(.x, 1))) %>%
  rename(
    "Énergie moy. (kJ)" = energie_100g,
    "Sucre moy. (g)"    = sucre_100g,
    "Protéines moy. (g)"= proteine_100g,
    "Nutriscore moy."   = nutriscore
  )

# ================================================================
# CSS GLOBAL
# ================================================================
css <- "
/* ---- Header — on passe le fond en gris foncé pour que le logo soit lisible ---- */
.skin-blue .main-header .logo {
  background-color: #4a4a4a !important;
  font-weight: 700;
  letter-spacing: .5px;
  font-size: 15px;
}
.skin-blue .main-header .navbar { background-color: #4a4a4a !important; }

/* ---- Sidebar ---- */
.skin-blue .main-sidebar { background-color: #2c3e50 !important; }
.skin-blue .sidebar-menu > li.active > a,
.skin-blue .sidebar-menu > li:hover  > a {
  background-color: #27ae60 !important;
  border-left: 4px solid #F1C40F !important;
}
.sidebar-menu > li > a { color: #ecf0f1 !important; font-size: 13px; }
.sidebar-menu .treeview-menu > li > a { color: #bdc3c7 !important; }
.user-panel { padding: 12px 10px; border-bottom: 1px solid #3d5166; }

/* ---- Background ---- */
.content-wrapper, .right-side { background-color: #f0f2f5 !important; }

/* ---- Boxes ---- */
.box { border-radius: 6px !important; box-shadow: 0 2px 8px rgba(0,0,0,.08) !important; }
.box-header { border-radius: 6px 6px 0 0 !important; }
.box.box-solid.box-success > .box-header { background:#27ae60 !important; color:#fff; }
.box.box-solid.box-primary > .box-header { background:#2980b9 !important; color:#fff; }
.box.box-solid.box-warning > .box-header { background:#e67e22 !important; color:#fff; }
.box.box-solid.box-danger  > .box-header { background:#e74c3c !important; color:#fff; }
.box.box-solid.box-info    > .box-header { background:#16a085 !important; color:#fff; }

/* ---- infoBox / valueBox ---- */
.info-box { border-radius: 6px !important; box-shadow: 0 2px 6px rgba(0,0,0,.1) !important; }
.info-box-icon { border-radius: 6px 0 0 6px !important; }

/* ---- KPI cards ---- */
.kpi-card {
  background: #fff;
  border-radius: 8px;
  padding: 18px 22px;
  box-shadow: 0 2px 8px rgba(0,0,0,.08);
  margin-bottom: 14px;
  border-left: 5px solid #27ae60;
}
.kpi-card.orange { border-left-color: #e67e22; }
.kpi-card.blue   { border-left-color: #2980b9; }
.kpi-card.red    { border-left-color: #e74c3c; }
.kpi-card h2 { margin:0; font-size:2em; font-weight:700; color:#2c3e50; }
.kpi-card p  { margin:4px 0 0; color:#7f8c8d; font-size:12px; }

/* ---- Interprétations ---- */
.interp-box {
  background: #eafaf1;
  border-left: 4px solid #27ae60;
  padding: 12px 16px;
  border-radius: 4px;
  font-size: 13px;
  color: #1a252f;
  line-height: 1.6;
}
.interp-box strong { color: #27ae60; }

.warn-box {
  background: #fef9e7;
  border-left: 4px solid #e67e22;
  padding: 12px 16px;
  border-radius: 4px;
  font-size: 13px;
  color: #1a252f;
  line-height: 1.6;
}

.info-box2 {
  background: #eaf4fb;
  border-left: 4px solid #2980b9;
  padding: 12px 16px;
  border-radius: 4px;
  font-size: 13px;
  color: #1a252f;
  line-height: 1.6;
}

/* ---- Nutriscore badges ---- */
.badge-A { background:#2ECC71; color:#fff; border-radius:4px; padding:2px 8px; font-weight:700; }
.badge-B { background:#A3E4D7; color:#fff; border-radius:4px; padding:2px 8px; font-weight:700; }
.badge-C { background:#F1C40F; color:#fff; border-radius:4px; padding:2px 8px; font-weight:700; }
.badge-D { background:#E67E22; color:#fff; border-radius:4px; padding:2px 8px; font-weight:700; }
.badge-E { background:#E74C3C; color:#fff; border-radius:4px; padding:2px 8px; font-weight:700; }

/* ---- Steps nettoyage ---- */
.step-card {
  display:flex; align-items:flex-start; gap:12px;
  background:#fff; border-radius:6px; padding:12px 16px;
  margin-bottom:10px; box-shadow:0 1px 4px rgba(0,0,0,.07);
}
.step-num {
  min-width:32px; height:32px; border-radius:50%;
  background:#27ae60; color:#fff;
  display:flex; align-items:center; justify-content:center;
  font-weight:700; font-size:14px;
}
.step-content strong { color:#2c3e50; }
.step-content p { margin:2px 0 0; color:#7f8c8d; font-size:12px; }

/* ---- Footer ---- */
.main-footer {
  background: #1a252f !important;
  color: #bdc3c7 !important;
  font-size: 12px;
  text-align: center;
  padding: 10px 20px;
}

/* ---- Tableau ---- */
.dataTables_wrapper { font-size:13px; }

/* ---- Conclusion ---- */
.conclusion-card {
  background: linear-gradient(135deg, #1a252f 0%, #2c3e50 100%);
  color: #fff; border-radius: 10px; padding: 28px 32px;
  box-shadow: 0 4px 16px rgba(0,0,0,.15);
}
.conclusion-card h3 { color: #2ECC71; margin-top:0; }
.conclusion-card p  { color: #ecf0f1; line-height:1.7; }
.conclusion-card ul li { color: #bdc3c7; margin-bottom: 6px; }

/* ---- Responsive ---- */
@media (max-width: 768px) {
  .kpi-card h2 { font-size: 1.5em; }
  .box { margin-bottom: 10px; }
}
"

# ================================================================
# UI
# ================================================================
ui <- dashboardPage(
  skin = "blue",
  
  # --- HEADER ---
  dashboardHeader(
    title = tags$span(
      tags$img(src = "logo.png", height = "32px",
               style = "margin-right:8px; vertical-align:middle;"),
      "Open Food Facts"
    ),
    titleWidth = 270
  ),
  
  # --- SIDEBAR ---
  dashboardSidebar(
    width = 270,
    div(class = "user-panel",
        tags$p(style = "color:#ecf0f1; font-size:11px; margin:0;",
               "BUT 2 SD — Parcours VCOD"),
        tags$span(style = "color:#bdc3c7; font-size:10px; margin:2px 0 0;",
                  "Christella DAVID"),
        tags$p(style = "color:#bdc3c7; font-size:10px; margin:2px 0 0;",
               "Santatriniaina RASOLOFOMANANA")
    ),
    sidebarMenu(
      menuItem("Vue d'ensemble",       tabName = "presentation", icon = icon("info-circle")),
      menuItem("Analyse Univariée",    tabName = "univariee",   icon = icon("chart-bar")),
      menuItem("Analyse Multivariée",  tabName = "multivariee", icon = icon("chart-line")),
      menuItem("ACP & Clustering",     tabName = "clustering",  icon = icon("project-diagram")),
      menuItem("Conclusion",           tabName = "conclusion",  icon = icon("check-circle")),
      tags$hr(style = "border-color:#3d5166; margin:10px 15px;"),
      tags$li(
        tags$a(href = "https://world.openfoodfacts.org/", target = "_blank",
               style = "color:#bdc3c7; font-size:12px; padding:6px 15px; display:block;",
               icon("external-link-alt"), " Open Food Facts")
      )
    )
  ),
  
  # --- BODY ---
  dashboardBody(
    tags$head(tags$style(HTML(css))),
    
    tabItems(
      
      # ============================================================
      # PAGE 1 — VUE D'ENSEMBLE
      # ============================================================
      tabItem("presentation",
              
              fluidRow(
                column(12,
                       tags$div(style = "margin-bottom:20px;",
                                tags$h2(style = "color:#2c3e50; font-weight:700; margin:0;",
                                        "Analyse des produits alimentaires — Open Food Facts"),
                                tags$p(style = "color:#7f8c8d; font-size:14px; margin:4px 0 0;",
                                       "Qualité nutritionnelle des produits vendus en France")
                       )
                )
              ),
              
              # KPI cards — chiffres clés calculés au chargement
              fluidRow(
                column(3,
                       div(class = "kpi-card",
                           tags$h2(textOutput("kpi_produits")),
                           tags$p("produits analysés")
                       )
                ),
                column(3,
                       div(class = "kpi-card blue",
                           tags$h2(textOutput("kpi_uniques")),
                           tags$p("noms de produits distincts")
                       )
                ),
                column(3,
                       div(class = "kpi-card orange",
                           tags$h2(textOutput("kpi_groupes")),
                           tags$p("groupes alimentaires")
                       )
                ),
                column(3,
                       div(class = "kpi-card red",
                           tags$h2("8"),
                           tags$p("variables nutritionnelles retenues")
                       )
                )
              ),
              
              fluidRow(
                box(title = "A propos de cet outil", width = 6, status = "success", solidHeader = TRUE,
                    tags$p(style = "font-size:13px; line-height:1.7;",
                           "Cet outil permet d'explorer la qualité nutritionnelle des produits alimentaires
              référencés dans la base Open Food Facts, une base collaborative et open source
              qui recense des milliers de produits vendus en France."),
                    tags$p(style = "font-size:13px; line-height:1.7;",
                           "Il a été développé dans le cadre d'une mission pour ",
                           tags$b("Santé publique France"),
                           ", afin d'identifier les grandes tendances nutritionnelles, repérer les catégories
              de produits les plus problématiques, et appuyer des décisions de santé publique
              sur des données concrètes."),
                    tags$p(style = "font-size:13px; line-height:1.7;",
                           "Utilisez les onglets pour naviguer entre l'analyse variable par variable,
              les comparaisons entre groupes alimentaires, et les profils nutritionnels identifiés.")
                ),
                
                box(title = "Lecture du Nutriscore", width = 6, status = "primary", solidHeader = TRUE,
                    # Le nutriscore (nutrition-score-fr_100g) est la variable cible de l'étude :
                    # il synthétise la qualité nutritionnelle globale d'un produit
                    tags$p(style = "font-size:13px; line-height:1.6; margin-bottom:12px;",
                           "Le Nutriscore classe les produits de A à E selon leur qualité nutritionnelle globale.
              Il tient compte de l'énergie, des sucres, des graisses saturées, du sel, mais aussi
              des éléments favorables comme les fibres et les protéines."),
                    div(class = "info-box2",
                        tags$ul(style = "margin:0; padding-left:18px;",
                                tags$li(tags$span(class="badge-A","A"), " — produit de bonne qualité nutritionnelle"),
                                tags$li(tags$span(class="badge-B","B"), " — qualité satisfaisante"),
                                tags$li(tags$span(class="badge-C","C"), " — qualité moyenne"),
                                tags$li(tags$span(class="badge-D","D"), " — qualité insuffisante"),
                                tags$li(tags$span(class="badge-E","E"), " — qualité nutritionnelle faible")
                        )
                    )
                )
              ),
              
              # Filtre + tableau explorable
              fluidRow(
                box(title = "Explorer les données",
                    width = 12, status = "primary", solidHeader = TRUE,
                    fluidRow(
                      column(4,
                             # Filtre sur pnns_groups_1 — catégorie alimentaire du produit
                             selectInput("filtre_groupe", "Filtrer par groupe alimentaire :",
                                         choices = c("Tous les groupes", sort(unique(data$groupe))),
                                         width = "100%")
                      ),
                      column(4,
                             # Filtre sur la classe Nutriscore dérivée du score nutritionnel
                             selectInput("filtre_ns", "Filtrer par classe Nutriscore :",
                                         choices = c("Toutes les classes", "A","B","C","D","E"),
                                         width = "100%")
                      ),
                      column(4,
                             div(style = "padding-top:26px;",
                                 div(class = "kpi-card", style = "padding:10px 16px; margin:0;",
                                     tags$h2(style="font-size:1.4em;", textOutput("n_filtre")),
                                     tags$p("produits dans la sélection")
                                 )
                             )
                      )
                    ),
                    tags$br(),
                    dataTableOutput("tableau_donnees")
                )
              )
      ),
      
      # ============================================================
      # PAGE 3 — ANALYSE UNIVARIÉE
      # Variables analysées une par une pour comprendre leur distribution individuelle
      # ============================================================
      tabItem("univariee",
              
              fluidRow(
                column(12,
                       tags$div(style = "margin-bottom:20px;",
                                tags$h2(style = "color:#2c3e50; font-weight:700; margin:0;",
                                        "Analyse variable par variable"),
                                tags$p(style = "color:#7f8c8d; font-size:14px; margin:4px 0 0;",
                                       "Sélectionnez une variable pour visualiser sa distribution et ses statistiques")
                       )
                )
              ),
              
              fluidRow(
                column(3,
                       box(width = 12, status = "success", solidHeader = FALSE,
                           # Sélecteur de variable — catégorielles (groupe, nutriscore, niveaux)
                           # et numériques (énergie, sucre, protéines, score)
                           selectInput("var_univ", "Variable à analyser :",
                                       choices = c(
                                         "Catégorielle" = "",
                                         "Groupe alimentaire"   = "groupe",
                                         "Classe Nutriscore"    = "nutriscore_classe",
                                         "Niveau de sucre"      = "niveau_sucre",
                                         "Niveau énergétique"   = "niveau_energie",
                                         "Riche en protéines"   = "riche_proteines",
                                         "Numérique" = "",
                                         "Énergie (kJ/100g)"    = "energie_100g",
                                         "Sucre (g/100g)"       = "sucre_100g",
                                         "Protéines (g/100g)"   = "proteine_100g",
                                         "Nutriscore (score)"   = "nutriscore"
                                       ), width = "100%"
                           )
                       ),
                       box(title = "Statistiques", width = 12,
                           status = "primary", solidHeader = TRUE,
                           tableOutput("stats_univ")
                       )
                ),
                column(9,
                       box(title = "Distribution", width = 12,
                           status = "success", solidHeader = TRUE,
                           plotOutput("plot_univ", height = "350px"),
                           tags$hr(style = "margin:12px 0 8px;"),
                           # Interprétation contextuelle selon la variable sélectionnée
                           div(class = "interp-box", uiOutput("interp_univ"))
                       )
                )
              )
      ),
      
      # ============================================================
      # PAGE 4 — ANALYSE MULTIVARIÉE
      # On croise les variables entre elles pour voir leurs relations
      # ============================================================
      tabItem("multivariee",
              
              fluidRow(
                column(12,
                       tags$div(style = "margin-bottom:20px;",
                                tags$h2(style = "color:#2c3e50; font-weight:700; margin:0;",
                                        "Comparaisons entre groupes"),
                                tags$p(style = "color:#7f8c8d; font-size:14px; margin:4px 0 0;",
                                       "Relations entre les variables nutritionnelles selon les catégories de produits")
                       )
                )
              ),
              
              # Graphique interactif — boxplot croisé entre deux variables au choix
              fluidRow(
                column(3,
                       box(width = 12, status = "warning", solidHeader = FALSE,
                           tags$p(style = "font-size:12px; color:#7f8c8d; margin-bottom:10px;",
                                  "Choisissez ce que vous voulez comparer :"),
                           # Y : variable numérique (énergie, sucre, protéines ou nutriscore)
                           selectInput("var_multi_y", "Valeur à comparer :",
                                       choices = c(
                                         "Énergie (kJ)"   = "energie_100g",
                                         "Sucre (g)"      = "sucre_100g",
                                         "Protéines (g)"  = "proteine_100g",
                                         "Nutriscore"     = "nutriscore"
                                       ), width = "100%"
                           ),
                           tags$br(),
                           # X : variable catégorielle de regroupement
                           selectInput("var_multi_x", "Grouper par :",
                                       choices = c(
                                         "Groupe alimentaire" = "groupe",
                                         "Classe Nutriscore"  = "nutriscore_classe",
                                         "Niveau de sucre"    = "niveau_sucre",
                                         "Niveau énergétique" = "niveau_energie",
                                         "Riche en protéines" = "riche_proteines"
                                       ), width = "100%"
                           )
                       )
                ),
                column(9,
                       box(title = "Comparaison par groupes", width = 12,
                           status = "success", solidHeader = TRUE,
                           plotOutput("plot_multi", height = "360px"),
                           tags$hr(style = "margin:10px 0 8px;"),
                           # Interprétation dynamique selon les variables choisies
                           div(class = "interp-box", uiOutput("interp_multi"))
                       )
                )
              ),
              
              tags$hr(style = "border-color:#e0e0e0; margin:10px 0 20px;"),
              
              # Nutriscore par groupe alimentaire — graphique en barres empilées + interprétation intégrée
              fluidRow(
                column(12,
                       box(title = "Répartition du Nutriscore par groupe alimentaire", width = 12,
                           status = "primary", solidHeader = TRUE,
                           fluidRow(
                             column(8,
                                    plotOutput("plot_nutri_groupe", height = "320px")
                             ),
                             column(4,
                                    div(style = "padding-top: 10px;",
                                        div(class = "interp-box",
                                            tags$p("Les ", tags$b("Sugary snacks"), " et ", tags$b("Salty snacks"),
                                                   " concentrent une forte proportion de produits classés D et E."),
                                            tags$p("Les ", tags$b("Fruits and vegetables"),
                                                   " se distinguent avec davantage de classes A et B."),
                                            tags$p("La qualité nutritionnelle d'un produit dépend donc fortement de sa catégorie.")
                                        )
                                    )
                             )
                           )
                       )
                )
              ),
              
              tags$hr(style = "border-color:#e0e0e0; margin:10px 0 20px;"),
              
              # Énergie, sucre, protéines et niveau énergétique selon le Nutriscore
              fluidRow(
                column(6,
                       box(title = "Énergie selon la classe Nutriscore", width = 12,
                           status = "success", solidHeader = TRUE,
                           plotOutput("plot_ener_ns", height = "280px"),
                           tags$hr(style = "margin:8px 0;"),
                           div(class = "interp-box",
                               "Les produits classés A et B consomment en moyenne moins d'énergie. Plus on avance vers E, plus les valeurs augmentent. Les produits les moins bien notés sont aussi les plus caloriques."
                           )
                       )
                ),
                column(6,
                       box(title = "Sucre selon la classe Nutriscore", width = 12,
                           status = "danger", solidHeader = TRUE,
                           plotOutput("plot_sucre_ns", height = "280px"),
                           tags$hr(style = "margin:8px 0;"),
                           div(class = "interp-box",
                               "La teneur en sucre suit la même logique : elle augmente de A vers E. Les produits en classe E contiennent en médiane bien plus de sucre que ceux en classe A."
                           )
                       )
                )
              ),
              
              fluidRow(
                column(6,
                       box(title = "Protéines selon la classe Nutriscore", width = 12,
                           status = "warning", solidHeader = TRUE,
                           plotOutput("plot_prot_ns", height = "280px"),
                           tags$hr(style = "margin:8px 0;"),
                           div(class = "interp-box",
                               "Contrairement à l'énergie et au sucre, les protéines ne suivent pas de tendance nette. Leur impact sur le score nutritionnel est moins déterminant."
                           )
                       )
                ),
                column(6,
                       box(title = "Niveau énergétique selon le Nutriscore", width = 12,
                           status = "info", solidHeader = TRUE,
                           plotOutput("plot_niv_ener_ns", height = "280px"),
                           tags$hr(style = "margin:8px 0;"),
                           div(class = "interp-box",
                               "La proportion de produits à forte énergie (rouge) augmente progressivement de la classe A vers la classe E. Les produits bien notés sont majoritairement peu caloriques."
                           )
                       )
                )
              )
      ),
      
      # ============================================================
      # PAGE 5 — ACP & CLUSTERING
      # Réduction de dimension et segmentation automatique des produits
      # ============================================================
      tabItem("clustering",
              
              fluidRow(
                column(12,
                       tags$div(style = "margin-bottom:20px;",
                                tags$h2(style = "color:#2c3e50; font-weight:700; margin:0;",
                                        "Profils nutritionnels"),
                                tags$p(style = "color:#7f8c8d; font-size:14px; margin:4px 0 0;",
                                       "Identification de groupes de produits aux caractéristiques similaires")
                       )
                )
              ),
              
              # ACP : projection des produits dans un espace réduit à 2 dimensions
              fluidRow(
                column(6,
                       box(title = "Projection ACP — vue d'ensemble des produits", width = 12,
                           status = "success", solidHeader = TRUE,
                           plotOutput("plot_acp", height = "380px"),
                           tags$hr(style = "margin:10px 0 8px;"),
                           div(class = "interp-box",
                               "Les classes A et B se regroupent à gauche, les classes D et E à droite. La classe C occupe le centre. Cette séparation confirme que le profil nutritionnel structure bien les différences entre produits."
                           )
                       )
                ),
                column(6,
                       box(title = "Part de l'information expliquée par chaque axe", width = 12,
                           status = "primary", solidHeader = TRUE,
                           # Scree plot : montre combien de variance est capturée par chaque axe de l'ACP
                           plotOutput("plot_scree", height = "220px")
                       ),
                       box(title = "Variables les plus influentes", width = 12,
                           status = "primary", solidHeader = TRUE,
                           # Contribution des variables aux axes principaux de l'ACP
                           plotOutput("plot_contrib", height = "200px")
                       )
                )
              ),
              
              tags$hr(style = "border-color:#e0e0e0; margin:10px 0 20px;"),
              
              # K-means : segmentation automatique en 3 profils nutritionnels
              fluidRow(
                column(7,
                       box(title = "Segmentation automatique — 3 profils identifiés", width = 12,
                           status = "warning", solidHeader = TRUE,
                           plotOutput("plot_kmeans", height = "380px"),
                           tags$hr(style = "margin:10px 0 8px;"),
                           div(class = "interp-box",
                               tags$p(tags$b("Groupe 1 — Produits favorables : "),
                                      "peu caloriques (environ 397 kJ), peu sucrés (environ 6 g), bon score nutritionnel. Correspond majoritairement aux classes A et B."),
                               tags$p(tags$b("Groupe 2 — Produits défavorables : "),
                                      "très énergétiques (environ 2 273 kJ), riches en sucre (environ 22 g), mauvais score. Correspond aux classes D et E."),
                               tags$p(tags$b("Groupe 3 — Profil intermédiaire : "),
                                      "valeurs modérées sur tous les critères. Correspond principalement à la classe C.")
                           )
                       )
                ),
                column(5,
                       box(title = "Valeurs moyennes par groupe", width = 12,
                           status = "info", solidHeader = TRUE,
                           # Tableau des moyennes par cluster — pour comprendre ce qui distingue chaque groupe
                           tableOutput("table_clusters")
                       ),
                       box(title = "Correspondance avec le Nutriscore", width = 12,
                           status = "info", solidHeader = TRUE,
                           plotOutput("plot_cluster_ns", height = "220px"),
                           tags$hr(style = "margin:10px 0 8px;"),
                           div(class = "interp-box",
                               "Les groupes identifiés automatiquement correspondent bien aux classes Nutriscore, ce qui valide la cohérence de la segmentation."
                           )
                       )
                )
              )
      ),
      
      # ============================================================
      # PAGE 6 — CONCLUSION
      # ============================================================
      tabItem("conclusion",
              
              fluidRow(
                column(12,
                       tags$div(style = "margin-bottom:20px;",
                                tags$h2(style = "color:#2c3e50; font-weight:700; margin:0;",
                                        "Conclusion"),
                                tags$p(style = "color:#7f8c8d; font-size:14px; margin:4px 0 0;",
                                       "Ce que les données révèlent sur la qualité nutritionnelle des produits vendus en France")
                       )
                )
              ),
              
              fluidRow(
                column(12,
                       div(class = "conclusion-card",
                           tags$h3("Ce que les données montrent"),
                           tags$p(
                             "L'analyse de la base Open Food Facts France révèle des tendances claires
                sur la qualité nutritionnelle des produits alimentaires disponibles sur le marché."
                           ),
                           tags$ul(
                             tags$li(tags$b("Une qualité globalement moyenne à faible : "),
                                     "Les classes C et D dominent la base, suivies de la classe E.
                  Les produits bien classés (A et B) restent minoritaires."),
                             tags$li(tags$b("Des écarts marqués selon le groupe alimentaire : "),
                                     "Les Sugary snacks, Salty snacks et Fat & sauces concentrent les profils les moins favorables.
                  Les Fruits and vegetables se distinguent avec les meilleures notes."),
                             tags$li(tags$b("L'énergie et le sucre sont les principaux déterminants du score : "),
                                     "Leur lien avec la classe Nutriscore est très fort sur toute l'échelle A à E.
                  Les protéines ont un effet plus limité et moins régulier."),
                             tags$li(tags$b("L'ACP confirme une structure claire : "),
                                     "Le premier axe sépare nettement les produits selon leur qualité nutritionnelle."),
                             tags$li(tags$b("Trois profils nutritionnels se dégagent : "),
                                     "Produits favorables, intermédiaires, et défavorables — cohérents avec les classes Nutriscore.")
                           ),
                           tags$hr(style = "border-color: #3d5166; margin: 16px 0;"),
                           tags$h3("Recommandations pour Santé publique France"),
                           tags$p("Sur la base de cette analyse :"),
                           tags$ul(
                             tags$li("Cibler en priorité les catégories ", tags$b("Sugary snacks"), " et ",
                                     tags$b("Salty snacks"), " pour des campagnes de sensibilisation nutritionnelle."),
                             tags$li("Améliorer le ", tags$b("taux de renseignement du groupe alimentaire"),
                                     " — une part importante des produits reste non classifiée."),
                             tags$li("S'appuyer sur la ", tags$b("classe Nutriscore"), " comme indicateur
                  synthétique fiable pour orienter les alertes consommateurs."),
                             tags$li("Enrichir la base avec les données de ", tags$b("graisses saturées"),
                                     " et de ", tags$b("fibres"), " pour affiner les analyses futures.")
                           ),
                           tags$hr(style = "border-color: #3d5166; margin: 16px 0;"),
                           tags$p(style = "color:#95a5a6; font-size:12px; text-align:right;",
                                  "Christella DAVID & Santatriniaina RASOLOFOMANANA")
                       )
                )
              ),
              
              tags$br(),
              
              fluidRow(
                box(title = "Répartition des classes Nutriscore",
                    width = 12, status = "success", solidHeader = TRUE,
                    plotOutput("plot_conclu_ns", height = "300px")
                )
              )
      )
      
    ), # fin tabItems
    
    # ---- FOOTER ----
    tags$footer(
      class = "main-footer",
      tags$span(
        "Analyse Open Food Facts — Christella DAVID & Santatriniaina RASOLOFOMANANA"
      ),
      tags$span(style = "float:right;",
                "Santé publique France"
      )
    )
    
  ) # fin dashboardBody
) # fin dashboardPage

# ================================================================
# SERVER
# ================================================================
server <- function(input, output) {
  
  # ── PAGE 1 — KPI ────────────────────────────────────────────
  output$kpi_produits <- renderText({ format(nb_produits, big.mark=" ") })
  output$kpi_uniques  <- renderText({ format(nb_uniques,  big.mark=" ") })
  output$kpi_groupes  <- renderText({ nb_groupes })
  
  # ── PAGE 1 — Données filtrées selon les sélecteurs ──────────
  donnees_filtrees <- reactive({
    df <- data
    if (input$filtre_groupe != "Tous les groupes")
      df <- df %>% filter(groupe == input$filtre_groupe)
    if (input$filtre_ns != "Toutes les classes")
      df <- df %>% filter(nutriscore_classe == input$filtre_ns)
    df
  })
  
  output$n_filtre <- renderText({
    format(nrow(donnees_filtrees()), big.mark = " ")
  })
  
  output$tableau_donnees <- renderDataTable({
    df <- donnees_filtrees() %>%
      select(nom_produit, groupe, energie_100g, sucre_100g,
             proteine_100g, nutriscore, nutriscore_classe,
             niveau_sucre, niveau_energie, riche_proteines)
    
    datatable(df,
              rownames = FALSE,
              filter   = "top",
              caption  = "Données nettoyées Open Food Facts — filtrables par colonne",
              colnames = c(
                "Produit","Groupe","Énergie (kJ)","Sucre (g)",
                "Protéines (g)","Nutriscore","Classe NS",
                "Niv. Sucre","Niv. Énergie","Riche Prot."
              ),
              options = list(
                pageLength = 12, scrollX = TRUE,
                dom = "lftip",
                language = list(
                  search = "Rechercher :",
                  lengthMenu = "Afficher _MENU_ entrées",
                  info = "Entrées _START_ à _END_ sur _TOTAL_",
                  paginate = list(previous = "Précédent", `next` = "Suivant")
                )
              )
    ) %>%
      formatStyle("nutriscore_classe",
                  backgroundColor = styleEqual(
                    c("A","B","C","D","E"),
                    c("#2ECC71","#A3E4D7","#F1C40F","#E67E22","#E74C3C")
                  ),
                  color = "white", fontWeight = "bold", textAlign = "center"
      ) %>%
      formatStyle("riche_proteines",
                  color = styleEqual(c("Oui","Non"), c("#27ae60","#e74c3c")),
                  fontWeight = "bold"
      ) %>%
      formatRound(c("energie_100g","sucre_100g","proteine_100g","nutriscore"), 2)
  })
  
  # ── PAGE 3 — UNIVARIÉE ─────────────────────────────────────
  vars_num <- c("energie_100g","sucre_100g","proteine_100g","nutriscore")
  
  # Tableau de statistiques descriptives (numérique) ou de fréquences (catégorielle)
  output$stats_univ <- renderTable({
    v <- input$var_univ
    if (v == "" || is.null(v)) return(NULL)
    if (v %in% vars_num) {
      data.frame(
        Statistique = c("Minimum","Q1 (25%)","Médiane","Moyenne","Q3 (75%)","Maximum","Écart-type"),
        Valeur = c(
          round(min(data[[v]],    na.rm=TRUE), 2),
          round(quantile(data[[v]], .25, na.rm=TRUE), 2),
          round(median(data[[v]], na.rm=TRUE), 2),
          round(mean(data[[v]],   na.rm=TRUE), 2),
          round(quantile(data[[v]], .75, na.rm=TRUE), 2),
          round(max(data[[v]],    na.rm=TRUE), 2),
          round(sd(data[[v]],     na.rm=TRUE), 2)
        )
      )
    } else {
      as.data.frame(table(data[[v]])) %>%
        rename(Modalité = Var1, Effectif = Freq) %>%
        mutate(`Proportion (%)` = round(Effectif / sum(Effectif) * 100, 1)) %>%
        arrange(desc(Effectif))
    }
  }, striped = TRUE, hover = TRUE, bordered = TRUE)
  
  output$distrib_univ <- renderTable({
    v <- input$var_univ
    if (v == "" || is.null(v)) return(NULL)
    if (v %in% vars_num) {
      data.frame(
        Mesure = c("Variance","Étendue","Valeurs manquantes","Asymétrie (skewness)"),
        Valeur = c(
          round(var(data[[v]], na.rm=TRUE), 2),
          round(max(data[[v]], na.rm=TRUE) - min(data[[v]], na.rm=TRUE), 2),
          sum(is.na(data[[v]])),
          round(mean((data[[v]] - mean(data[[v]], na.rm=TRUE))^3, na.rm=TRUE) /
                  sd(data[[v]], na.rm=TRUE)^3, 2)
        )
      )
    } else {
      tbl <- as.data.frame(table(data[[v]])) %>%
        rename(Modalité = Var1, Effectif = Freq) %>%
        mutate(`%` = round(Effectif/sum(Effectif)*100,1))
      tbl[order(-tbl$Effectif), ]
    }
  }, striped = TRUE, hover = TRUE, bordered = TRUE)
  
  # Graphique adapté selon le type de variable sélectionnée
  output$plot_univ <- renderPlot({
    v <- input$var_univ
    if (v == "" || is.null(v)) return(NULL)
    
    if (v == "groupe") {
      # pnns_groups_1 — catégorie alimentaire : permet de voir la répartition entre familles de produits
      ggplot(data, aes(x = reorder(groupe, groupe, function(x) -length(x)))) +
        geom_bar(fill = vert, color = "white") +
        theme_off +
        labs(title = "Répartition des groupes alimentaires",
             subtitle = "Nombre de produits par groupe (pnns_groups_1)",
             x = "", y = "Nombre de produits")
      
    } else if (v == "nutriscore_classe") {
      # Classe Nutriscore dérivée du score nutrition-score-fr_100g
      ggplot(data, aes(x = nutriscore_classe, fill = nutriscore_classe)) +
        geom_bar(color = "white") +
        scale_fill_manual(values = couleurs_ns) +
        theme_off + theme(legend.position = "none") +
        labs(title = "Répartition des classes Nutriscore",
             subtitle = "Les classes C et D dominent la base",
             x = "Classe Nutriscore", y = "Nombre de produits")
      
    } else if (v == "niveau_sucre") {
      # Niveau dérivé de sugars_100g : Faible ≤5g / Moyen 5–12,5g / Élevé >12,5g
      ggplot(data, aes(x = factor(niveau_sucre, levels=c("Faible","Moyen","Élevé")),
                       fill = niveau_sucre)) +
        geom_bar(color="white") +
        scale_fill_manual(values = couleurs_sucre) +
        theme_off + theme(legend.position="none") +
        labs(title="Niveau de sucre des produits",
             subtitle="Faible ≤5g | Moyen 5–12,5g | Élevé >12,5g",
             x="", y="Nombre de produits")
      
    } else if (v == "niveau_energie") {
      # Niveau dérivé de energy_100g : Faible ≤1000kJ / Moyenne 1000–2000kJ / Élevée >2000kJ
      ggplot(data, aes(x = factor(niveau_energie, levels=c("Faible","Moyenne","Élevée")),
                       fill = niveau_energie)) +
        geom_bar(color="white") +
        scale_fill_manual(values = couleurs_ener) +
        theme_off + theme(legend.position="none") +
        labs(title="Niveau énergétique des produits",
             subtitle="Faible ≤1000kJ | Moyenne 1000–2000kJ | Élevée >2000kJ",
             x="", y="Nombre de produits")
      
    } else if (v == "riche_proteines") {
      # Variable booléenne dérivée de proteins_100g : riche si ≥ 10g/100g
      ggplot(data, aes(x = riche_proteines, fill = riche_proteines)) +
        geom_bar(color="white") +
        scale_fill_manual(values = couleurs_prot) +
        theme_off + theme(legend.position="none") +
        labs(title="Produits riches en protéines",
             subtitle="Riche : protéines ≥ 10g/100g",
             x="", y="Nombre de produits")
      
    } else if (v == "nutriscore") {
      # Score brut nutrition-score-fr_100g — variable cible de l'étude
      ggplot(data, aes(x = nutriscore)) +
        geom_histogram(fill = orange, bins = 30, color = "white") +
        geom_vline(xintercept = mean(data$nutriscore, na.rm=TRUE),
                   color = rouge, linetype = "dashed", linewidth = 1) +
        annotate("text", x = mean(data$nutriscore,na.rm=TRUE)+0.5,
                 y = Inf, vjust=2, hjust=0, color=rouge, size=3.5,
                 label = paste0("Moy. = ", round(mean(data$nutriscore,na.rm=TRUE),1))) +
        theme_off + theme(axis.text.x = element_text(angle=0)) +
        labs(title="Distribution du Nutriscore",
             subtitle="Score nutritionnel FR — plus élevé = moins bon",
             x="Nutriscore", y="Nombre de produits")
      
    } else {
      # Variables numériques : énergie (energy_100g), sucre (sugars_100g), protéines (proteins_100g)
      fill_col <- switch(v,
                         "energie_100g"  = jaune,
                         "sucre_100g"    = rouge,
                         "proteine_100g" = vert
      )
      ggplot(data, aes(y = .data[[v]])) +
        geom_boxplot(fill = fill_col, alpha = 0.8, color = "#2c3e50", outlier.color = rouge) +
        theme_off + theme(axis.text.x = element_blank(), axis.text.y = element_text(angle=0)) +
        labs(title = paste("Distribution de :", v),
             subtitle = "Boxplot avec valeurs aberrantes",
             y = v, x = "")
    }
  })
  
  # Interprétations pour chaque variable
  output$interp_univ <- renderUI({
    interps <- list(
      "groupe"          = tags$p(tags$strong("Observation : "), "Certaines catégories sont beaucoup plus présentes que d'autres. La catégorie 'Unknown' domine largement, ce qui montre que beaucoup de données ne sont pas renseignées. Les 'Sugary snacks' sont aussi assez nombreux, contrairement à d'autres groupes moins représentés."),
      "energie_100g"    = tags$p(tags$strong("Observation : "), "La majorité des produits ont une énergie proche de 1000 kJ, donc des valeurs assez standard. Quelques produits ont des valeurs très élevées, mais restent minoritaires. La base contient à la fois des produits classiques et des produits très caloriques."),
      "sucre_100g"      = tags$p(tags$strong("Observation : "), "La majorité des produits ont un faible taux de sucre, avec des valeurs proches de 0. Plusieurs produits présentent des valeurs très élevées, jusqu'à 100g. La base contient à la fois des produits peu sucrés et des produits très riches en sucre."),
      "proteine_100g"   = tags$p(tags$strong("Observation : "), "La majorité des produits ont une faible teneur en protéines, avec des valeurs généralement basses. Certains produits présentent des valeurs plus élevées, mais restent moins fréquents. La base contient surtout des produits peu riches en protéines, avec quelques aliments plus protéinés."),
      "nutriscore"      = tags$p(tags$strong("Observation : "), "Le nutriscore est assez étalé, avec une concentration autour des valeurs moyennes. On observe plus de valeurs positives, donc des produits plutôt moins bons sur le plan nutritionnel. La base contient une majorité de produits de qualité nutritionnelle moyenne à faible."),
      "nutriscore_classe" = tags$p(tags$strong("Observation : "), "Les classes C et D sont les plus représentées, suivies de la classe E. Les classes A et B sont moins présentes dans la base. Donc, une grande partie des produits ont une qualité nutritionnelle moyenne à faible."),
      "niveau_sucre"    = tags$p(tags$strong("Observation : "), "La majorité des produits sont classés avec un faible niveau de sucre. Une part importante correspond aussi à des produits avec un niveau élevé. La base contient beaucoup de produits peu sucrés, mais aussi une quantité importante de produits riches en sucre."),
      "niveau_energie"  = tags$p(tags$strong("Observation : "), "La majorité des produits ont un niveau énergétique faible, avec une part importante en niveau moyen. Les produits très énergétiques sont moins nombreux. La base contient surtout des produits peu caloriques, avec moins de produits à forte densité énergétique."),
      "riche_proteines" = tags$p(tags$strong("Observation : "), "La majorité des produits ne sont pas riches en protéines. Les produits riches en protéines sont présents mais moins nombreux. La base contient surtout des produits avec un faible apport en protéines.")
    )
    v <- input$var_univ
    if (v == "" || is.null(v) || is.null(interps[[v]])) return(NULL)
    interps[[v]]
  })
  
  # ── PAGE 4 — MULTIVARIÉE ───────────────────────────────────
  
  # Boxplot croisé — on compare une variable numérique selon une variable catégorielle
  output$plot_multi <- renderPlot({
    y <- input$var_multi_y
    x <- input$var_multi_x
    
    fill_scale <- if (x == "nutriscore_classe") {
      scale_fill_manual(values = couleurs_ns)
    } else if (x == "niveau_sucre") {
      scale_fill_manual(values = couleurs_sucre)
    } else if (x == "niveau_energie") {
      scale_fill_manual(values = couleurs_ener)
    } else if (x == "riche_proteines") {
      scale_fill_manual(values = couleurs_prot)
    } else {
      scale_fill_viridis_d(option = "D")
    }
    
    ggplot(data, aes_string(x = x, y = y, fill = x)) +
      geom_boxplot(color = "#2c3e50", outlier.color = rouge, outlier.size = 1) +
      fill_scale +
      theme_off + theme(legend.position = "none") +
      labs(title = paste("Distribution de", y, "selon", x),
           x = "", y = y)
  })
  
  # Interprétation dynamique selon la combinaison de variables choisie
  output$interp_multi <- renderUI({
    y <- input$var_multi_y
    x <- input$var_multi_x
    key <- paste(y, x, sep="_")
    
    interps <- list(
      "energie_100g_groupe"  = "L'énergie varie fortement selon les groupes alimentaires. Les 'Fat and sauces', 'Salty snacks' et 'Sugary snacks' ont des niveaux plus élevés. Les 'Fruits and vegetables' et 'Beverages' ont des valeurs plus faibles. → Certains types de produits sont clairement plus caloriques que d'autres.",
      "sucre_100g_groupe"    = "Le taux de sucre varie selon les groupes alimentaires. Les 'Sugary snacks' ont les niveaux les plus élevés, avec une forte dispersion. Les 'Composite foods' et 'Fish meat eggs' ont des niveaux plus faibles. → Certains types de produits sont clairement plus sucrés que d'autres.",
      "proteine_100g_groupe" = "Les protéines varient selon les groupes alimentaires. Les 'Fish meat eggs' ont les niveaux les plus élevés. Les 'Fat and sauces' et 'Fruits and vegetables' ont des niveaux plus faibles. → Certains types de produits apportent plus de protéines que d'autres.",
      "nutriscore_groupe"    = "Le nutriscore varie selon les groupes alimentaires. Les 'Sugary snacks' et 'Salty snacks' ont des valeurs plus élevées, donc une qualité plus faible. Les 'Fruits and vegetables' ont des valeurs plus basses, donc une meilleure qualité. → La qualité des produits dépend clairement du type de groupe alimentaire.",
      "energie_100g_nutriscore_classe" = "L'énergie augmente quand on passe de A vers E. Les produits mieux classés (A, B) ont des valeurs plus faibles. Les produits mal classés (D, E) ont des niveaux plus élevés. → Les produits moins bons sont globalement plus caloriques.",
      "sucre_100g_nutriscore_classe"   = "Le taux de sucre augmente clairement de A vers E. Les classes A et B ont des valeurs faibles, alors que D et E sont plus élevées. L'écart est important surtout pour les classes D et E. → Les produits moins bien classés sont plus sucrés."
    )
    
    txt <- if (!is.null(interps[[key]])) interps[[key]]
    else paste("Comparaison de", y, "selon", x,
               "— Les différences entre groupes reflètent la composition nutritionnelle propre à chaque catégorie.")
    div(class = "interp-box", tags$p(tags$strong("Interprétation : "), txt))
  })
  
  # Nutriscore par groupe alimentaire — barres empilées en proportions
  output$plot_nutri_groupe <- renderPlot({
    ggplot(data, aes(x = reorder(groupe, groupe, function(x) -length(x)),
                     fill = nutriscore_classe)) +
      geom_bar(position = "fill", color = "white") +
      scale_fill_manual(values = couleurs_ns, name = "Nutriscore") +
      theme_off +
      labs(title = "Répartition du Nutriscore par groupe alimentaire",
           subtitle = "Proportion de chaque classe A→E par groupe",
           x = "", y = "Proportion")
  })
  
  # Énergie selon le nutriscore
  output$plot_ener_ns <- renderPlot({
    ggplot(data, aes(x = nutriscore_classe, y = energie_100g, fill = nutriscore_classe)) +
      geom_boxplot(color = "#2c3e50", outlier.color = rouge) +
      scale_fill_manual(values = couleurs_ns) +
      theme_off + theme(legend.position = "none") +
      labs(title = "Énergie selon le Nutriscore", x = "Classe Nutriscore", y = "Énergie (kJ/100g)")
  })
  
  # Sucre selon le nutriscore
  output$plot_sucre_ns <- renderPlot({
    ggplot(data, aes(x = nutriscore_classe, y = sucre_100g, fill = nutriscore_classe)) +
      geom_boxplot(color = "#2c3e50", outlier.color = rouge) +
      scale_fill_manual(values = couleurs_ns) +
      theme_off + theme(legend.position = "none") +
      labs(title = "Sucre selon le Nutriscore", x = "Classe Nutriscore", y = "Sucre (g/100g)")
  })
  
  # Protéines selon le nutriscore — ici on utilise la moyenne plutôt qu'un boxplot
  output$plot_prot_ns <- renderPlot({
    ggplot(data, aes(x = nutriscore_classe, y = proteine_100g, fill = nutriscore_classe)) +
      stat_summary(fun = mean, geom = "bar", color = "white") +
      scale_fill_manual(values = couleurs_ns) +
      theme_off + theme(legend.position = "none") +
      labs(title = "Protéines (moyenne) selon le Nutriscore",
           x = "Classe Nutriscore", y = "Protéines moy. (g/100g)")
  })
  
  # Niveau énergétique selon le nutriscore — barres empilées en proportions
  output$plot_niv_ener_ns <- renderPlot({
    ggplot(data, aes(x = nutriscore_classe, fill = niveau_energie)) +
      geom_bar(position = "fill", color = "white") +
      scale_fill_manual(values = couleurs_ener, name = "Niveau énergie") +
      theme_off +
      labs(title = "Niveau énergétique selon le Nutriscore",
           x = "Classe Nutriscore", y = "Proportion")
  })
  
  # ── PAGE 5 — ACP & CLUSTERING ──────────────────────────────
  
  # Projection ACP — chaque point est un produit, coloré par classe Nutriscore
  output$plot_acp <- renderPlot({
    fviz_pca_ind(acp,
                 geom         = "point",
                 col.ind      = data$nutriscore_classe,
                 palette      = unname(couleurs_ns),
                 addEllipses  = TRUE,
                 ellipse.type = "confidence",
                 legend.title = "Nutriscore",
                 title        = "ACP — Projection des produits (colorés par classe Nutriscore)",
                 ggtheme      = theme_minimal(base_size = 12)
    )
  })
  
  # Scree plot — variance expliquée par axe
  output$plot_scree <- renderPlot({
    fviz_eig(acp, addlabels = TRUE,
             barfill = bleu, barcolor = "white",
             linecolor = rouge,
             title = "Variance expliquée par axe",
             ggtheme = theme_minimal(base_size = 11))
  })
  
  # Contribution des variables aux deux premiers axes de l'ACP
  output$plot_contrib <- renderPlot({
    fviz_contrib(acp, choice = "var", axes = 1:2,
                 fill = vert, color = "white",
                 title = "Contribution des variables (Dim 1+2)",
                 ggtheme = theme_minimal(base_size = 11))
  })
  
  # K-means — visualisation des 3 clusters dans l'espace ACP
  output$plot_kmeans <- renderPlot({
    fviz_cluster(km,
                 data         = data_num,
                 geom         = "point",
                 ellipse.type = "norm",
                 palette      = c(bleu, rouge, jaune),
                 ggtheme      = theme_minimal(base_size = 12),
                 main         = "K-means — 3 profils nutritionnels (k=3, nstart=25)"
    )
  })
  
  # Tableau résumé des moyennes par cluster
  output$table_clusters <- renderTable({
    profils_clusters
  }, striped = TRUE, hover = TRUE, bordered = TRUE)
  
  # Correspondance entre les clusters et les classes Nutriscore
  output$plot_cluster_ns <- renderPlot({
    ggplot(data, aes(x = cluster, fill = nutriscore_classe)) +
      geom_bar(position = "fill", color = "white") +
      scale_fill_manual(values = couleurs_ns, name = "Nutriscore") +
      theme_off + theme(axis.text.x = element_text(angle=0)) +
      labs(title = "Clusters × Classes Nutriscore",
           x = "Cluster", y = "Proportion")
  })
  
  # ── PAGE 6 — CONCLUSION ────────────────────────────────────
  output$plot_conclu_ns <- renderPlot({
    ggplot(data, aes(x = nutriscore_classe, fill = nutriscore_classe)) +
      geom_bar(color = "white") +
      scale_fill_manual(values = couleurs_ns) +
      theme_off + theme(legend.position = "none") +
      geom_text(stat = "count",
                aes(label = after_stat(count)),
                vjust = -0.5, size = 4, fontface = "bold") +
      labs(title = "Répartition finale des classes Nutriscore",
           subtitle = "Après nettoyage et préparation des données",
           x = "Classe Nutriscore", y = "Nombre de produits")
  })
  
} # fin server

# ================================================================
shinyApp(ui = ui, server = server)

