# DAVID & RASOLOFOMANANA - BUT 2 FA VCOD
# Nettoyage et préparation des données Open Food Facts

# PACKAGES
library(tidyverse)# manipuler les données
library(lubridate)# utile pour les dates
library(stringr)# traitement des chaînes de caractères

# CHARGEMENT DES DONNÉES
data <- read.csv(
  "D:/reporting_multivarie_princia/data.csv",
  stringsAsFactors = FALSE,
  fileEncoding = "UTF-8"
)

# EXPLORATION DES DONNÉES
# structure et reperer anomalies
str(data)
glimpse(data)
head(data)

# Nombre de valeurs manquantes
sort(colSums(is.na(data)), decreasing = TRUE)

# Types des variables
sapply(data, class)

# Doublons produits
sum(duplicated(data$code))


summary(data)


#NETTOYAGE
# Sélection des variables utiles uniquement
data <- data %>%
  select(
    code,
    product_name,
    last_modified_datetime,
    pnns_groups_1,
    energy_100g,
    sugars_100g,
    proteins_100g,
    `nutrition.score.fr_100g`
  )

#Renommage
data <- data %>%
  rename(
    nom_produit = product_name,
    date_modification = last_modified_datetime,
    groupe = pnns_groups_1,
    energie_100g = energy_100g,
    sucre_100g = sugars_100g,
    proteine_100g = proteins_100g,
    nutriscore = `nutrition.score.fr_100g`
  )

# VARIABLE CODE
# On veut mettre tous les codes homogènes (même longueur)
data$code <- as.character(data$code)
max_length <- max(nchar(data$code), na.rm = TRUE)
data$code <- str_pad(
  data$code,
  width = max_length,
  side = "left",
  pad = "0"
)

# Suppression des doublons
data <- data %>%
  distinct(code, .keep_all = TRUE)

# VARIABLE DATE
# Conversion en date 
data$date_modification <- parse_date_time(
  data$date_modification,
  orders = c("ymd HMS", "ymd HM", "ymd", "dmy HMS", "dmy")
)

data$date_modification <- format(data$date_modification, "%d/%m/%Y")

# VARIABLE GROUPE ALIMENTAIRE
# Mettre tout au même format
data$groupe <- data$groupe %>%
  tolower() %>% # tout en minuscule
  str_replace_all("-", " ") %>% # enlever "-"
  str_trim()                    # enlever espaces inutiles

# Première lettre majuscule
data$groupe <- str_to_sentence(data$groupe)

# Remplacer les valeurs vides par unknown
data$groupe[data$groupe == "" | is.na(data$groupe)] <- "Unknown"

# VARIABLE ENERGIE
# Plage énergie : entre 0 et 5000
data$energie_100g <- as.numeric(gsub(",", ".", data$energie_100g))
# Suppression valeurs aberrantes (erreurs de frappe)
data$energie_100g[data$energie_100g > 5000 | data$energie_100g < 0] <- NA

# Remplacement par médiane 
median_energy <- median(data$energie_100g, na.rm = TRUE)
data$energie_100g[is.na(data$energie_100g)] <- median_energy

data$energie_100g <- round(data$energie_100g, 2)

# VARIABLE SUCRE
data$sucre_100g <- as.numeric(data$sucre_100g)
# Plage sucre : entre 0 et 100
data$sucre_100g[data$sucre_100g < 0 | data$sucre_100g > 100] <- NA

# Remplacement par médiane
data$sucre_100g[is.na(data$sucre_100g)] <- median(data$sucre_100g, na.rm = TRUE)

# VARIABLE PROTEINES
data$proteine_100g <- as.numeric(data$proteine_100g)
#Plage proteine : entre 0 et 50
data$proteine_100g[data$proteine_100g < 0 | data$proteine_100g > 50] <- NA

data$proteine_100g[is.na(data$proteine_100g)] <- median(data$proteine_100g, na.rm = TRUE)

# VARIABLE NUTRISCORE
data$nutriscore <- as.numeric(data$nutriscore)

# Plage nutriscore : entre -15 et 40
data$nutriscore[data$nutriscore < -15 | data$nutriscore > 40] <- NA

data$nutriscore[is.na(data$nutriscore)] <- median(data$nutriscore, na.rm = TRUE)

# VERIFICATION
summary(data)
sort(colSums(is.na(data)), decreasing = TRUE)

# CREATION VARIABLES 

# Classe Nutriscore : Ça permet de rendre le nutriscore plus facile à comprendre, au lieu d’avoir juste un nombre on a directement une catégorie.
data$nutriscore_classe <- cut(
  data$nutriscore,
  breaks = c(-Inf, -1, 2, 10, 18, Inf),
  labels = c("A", "B", "C", "D", "E")
)

# Niveau de sucre : Ça sert à voir rapidement si un produit est peu ou très sucré.
data$niveau_sucre <- cut(
  data$sucre_100g,
  breaks = c(-Inf, 5, 12.5, Inf),
  labels = c("Faible", "Moyen", "Élevé")
)

# Niveau énergétique : Ça permet de repérer facilement les produits très caloriques ou pas.
data$niveau_energie <- cut(
  data$energie_100g,
  breaks = c(-Inf, 1000, 2000, Inf),
  labels = c("Faible", "Moyenne", "Élevée")
)

# Produits riches en protéines : Ça aide à identifier les produits qui apportent beaucoup de protéines.
data$riche_proteines <- ifelse(data$proteine_100g >= 10, "Oui", "Non")

# EXPORTATION DONNEES
write.csv(
  data,
  "D:/reporting_multivarie_princia/donnees_nettoyees.csv",
  row.names = FALSE
)



#FONCTION NETTOYAGE
nettoyer_donnees <- function(df) {
  
  df <- df %>%
    select(
      code,
      product_name,
      last_modified_datetime,
      pnns_groups_1,
      energy_100g,
      sugars_100g,
      proteins_100g,
      `nutrition.score.fr_100g`
    )
  
  df <- df %>%
    rename(
      nom_produit = product_name,
      date_modification = last_modified_datetime,
      groupe = pnns_groups_1,
      energie_100g = energy_100g,
      sucre_100g = sugars_100g,
      proteine_100g = proteins_100g,
      nutriscore = `nutrition.score.fr_100g`
    )
  
  df$code <- as.character(df$code)
  max_length <- max(nchar(df$code), na.rm = TRUE)
  df$code <- str_pad(df$code, width = max_length, side = "left", pad = "0")
  
  df <- df %>% distinct(code, .keep_all = TRUE)
  
  df$date_modification <- parse_date_time(
    df$date_modification,
    orders = c("ymd HMS", "ymd HM", "ymd", "dmy HMS", "dmy")
  )
  
  df$date_modification <- format(df$date_modification, "%d/%m/%Y")
  
  df$groupe <- df$groupe %>%
    tolower() %>%
    str_replace_all("-", " ") %>%
    str_trim()
  
  df$groupe <- str_to_sentence(df$groupe)
  df$groupe[df$groupe == "" | is.na(df$groupe)] <- "Unknown"
  
  df$energie_100g <- as.numeric(gsub(",", ".", df$energie_100g))
  df$energie_100g[df$energie_100g > 5000 | df$energie_100g < 0] <- NA
  df$energie_100g[is.na(df$energie_100g)] <- median(df$energie_100g, na.rm = TRUE)
  
  df$sucre_100g <- as.numeric(df$sucre_100g)
  df$sucre_100g[df$sucre_100g < 0 | df$sucre_100g > 100] <- NA
  df$sucre_100g[is.na(df$sucre_100g)] <- median(df$sucre_100g, na.rm = TRUE)
  
  df$proteine_100g <- as.numeric(df$proteine_100g)
  df$proteine_100g[df$proteine_100g < 0 | df$proteine_100g > 50] <- NA
  df$proteine_100g[is.na(df$proteine_100g)] <- median(df$proteine_100g, na.rm = TRUE)
  
  df$nutriscore <- as.numeric(df$nutriscore)
  df$nutriscore[df$nutriscore < -15 | df$nutriscore > 40] <- NA
  df$nutriscore[is.na(df$nutriscore)] <- median(df$nutriscore, na.rm = TRUE)
  
  df$nutriscore_classe <- cut(df$nutriscore,
                              breaks = c(-Inf, -1, 2, 10, 18, Inf),
                              labels = c("A", "B", "C", "D", "E"))
  
  df$niveau_sucre <- cut(df$sucre_100g,
                         breaks = c(-Inf, 5, 12.5, Inf),
                         labels = c("Faible", "Moyen", "Élevé"))
  
  df$niveau_energie <- cut(df$energie_100g,
                           breaks = c(-Inf, 1000, 2000, Inf),
                           labels = c("Faible", "Moyenne", "Élevée"))
  
  df$riche_proteines <- ifelse(df$proteine_100g >= 10, "Oui", "Non")
  
  return(df)
}
#test
data_test <- nettoyer_donnees(data)